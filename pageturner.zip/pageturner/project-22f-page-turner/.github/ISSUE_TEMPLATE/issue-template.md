---
name: regular issue template
about: ''

---

# Title

One to two sentence description. Add current and expected behavior if the issue is a bug.

## Type of Issue

- [ ] New feature
- [ ] Bug fix
- [ ] Documentation update
- [ ] User research/testing
- [ ] Wireframe/mockup
- [ ] Other

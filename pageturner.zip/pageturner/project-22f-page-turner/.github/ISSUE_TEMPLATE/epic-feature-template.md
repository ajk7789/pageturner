---
name: Epic/Feature Template
about: for features

---

Motivations:
* As *user persona x*, I want to *do task y* so I can *accomplish goal z*

import React from 'react';
import {
  BrowserRouter as Router,
  Route,
  Routes,
} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';
import './App.css';
import {SideBar} from './components/Sidebar/SideBar';
import {ProfilePage} from './components/ProfilePage';
import {GroupProfilePage} from './components/ProfilePage/GroupProfilePage';
import {BookInfo} from './components/BookInfo';
import {HomePage} from './components/HomePage';
import {ThreadView} from './components/ThreadView/ThreadView';
import {RightBar} from './components/RightBar';
import {BookClubsPage} from './components/BookClubsPage';
import {BookClubHome} from './components/BookClubsPage/BookClubHome';
import {Notification} from './components/Notification';
import ReactGA from 'react-ga';

const TRACKING_ID = 'UA-257505042-1';
ReactGA.initialize(TRACKING_ID);

/**
 * Core React component
 * Handles auth, navigation, etc.
 * @return {JSX} component containing entire application
 */
const App = () => {
  return (
    <div className="min-h-screen mx-auto max-w-7xl flex">
      <Router>
        <SideBar />
        <main className="flex-1 flex flex-col bg-white">
          <Routes>
            <Route exact path="/" element={<HomePage />} />
            <Route path='/book-clubs' element={<BookClubsPage />} />
            <Route path='/book-clubs/:clubId' element={<BookClubHome />} />
            <Route path='/book-clubs/:clubId/about' element={<GroupProfilePage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/profile/:uid" element={<ProfilePage />} />
            <Route path="/group-profile" element={<GroupProfilePage />} />
            <Route path="/book-info/*" element={<BookInfo />} />
            <Route path="/thread/:clubId/:commentIdParam" element={<ThreadView />}/>
            <Route path="/thread/:commentIdParam" element={<ThreadView />}/>
            <Route path="/notifications" element={<Notification />}/>
          </Routes>
        </main>
        <aside className="w-350">
          <RightBar />
        </aside>
      </Router>
    </div>
  );
};

export default App;

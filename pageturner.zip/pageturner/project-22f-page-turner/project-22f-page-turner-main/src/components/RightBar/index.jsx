import {React} from 'react';

import {Trending} from './Trending';

export const RightBar = () => {
  return (
    <div className="pt-2 bg-white h-full">
      <Trending />
    </div>
  );
};

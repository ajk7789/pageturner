/*
 * Build a feed for user's homepage
 * Returns relevant comments for the logged in user
 */

import React, {useEffect, useState} from 'react';
import {getClubFeed} from '../../api';
import {Comment} from '../Comment/Comment';
import ReactLoading from 'react-loading';

/**
 * Component representing the book club's social feed
 * @param {*} club passed from BookClubHome component
 * @return {jsx}
 */
export const ClubTimeline = ({club}) => {
  const [timeline, setTimeline] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAddingPage, setIsAddingPage] = useState(false);
  const [pageNumber, setPageNumber] = useState(0);
  const [isGettingPage, setIsGettingPage] = useState(false);
  const [noMorePages, setNoMorePages] = useState(false);

  /**
   * fetches the club's feed data from the database
   */
  const fetchData = async () => {
    try {
      const newTimeline = await getClubFeed(club._id, pageNumber);
      setTimeline(newTimeline);
    } catch (err) {
      console.log(err);
    }
  };

  // Create event listener for newPost in sessionStorage
  window.addEventListener('newClubPost', () => {
    if (!isLoading) {
      setPageNumber(0);
      setIsLoading(true);
    }
  });

  // Create event listener for infinite scroll
  document.addEventListener('scroll', function() {
    if (document.body.scrollHeight <= Math.ceil(window.pageYOffset + window.innerHeight)) {
      setIsAddingPage(true);
    }
  });

  /**
   * retrieves a new timeline page to be added
   * if the user scrolls far enough
   */
  const getNewTimelinePage = async () => {
    if (!isGettingPage && !noMorePages) {
      setIsGettingPage(true);
      try {
        const newTimelinePage = await getClubFeed(club._id, pageNumber+1);
        const newTimeline = timeline.concat(newTimelinePage);
        setTimeline(newTimeline);
        if (newTimelinePage.length > 0) {
          setPrivatePageNumber(pageNumber+1);
        } else {
          setNoMorePages(true);
        }
      } catch (err) {
        console.log(err);
      }
      setIsGettingPage(false);
    }
  };

  /**
   * gets the new timeline page when the event
   * listener for scrolling is triggered
   * @trigger isAddingPage changes when user
   * scrolls far enough and triggers event listener
   */
  useEffect(() => {
    if (isAddingPage) {
      setIsAddingPage(false);
      getNewTimelinePage();
    }
  }, [isAddingPage]);

  /**
   * fetches data when the timeline is loading
   * @trigger isLoading changes when a new post
   * is submitted
   */
  useEffect(() => {
    if (isLoading) {
      setIsLoading(false);
      fetchData();
    }
  }, [isLoading]);

  return (
    <div className="bg-white h-full">
      {timeline && timeline.map((commentData) =>
        (<div key={commentData._id}>
          <Comment comment={commentData}/>
          <div className="border-b ml-3 mr-3 border-slate-300"></div>
        </div>
        ))}
      {isGettingPage && <ReactLoading type="spin" color="black" />}
    </div>
  );
};

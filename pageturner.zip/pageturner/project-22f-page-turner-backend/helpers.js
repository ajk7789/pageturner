// Get database
const {dbConn} = require('./mongo');

/**
 * Adjoin profile information to an array of comments
 * @param {Array} comments - comments to get profile info for
 * @return {Array} new comments
 */
async function addProfiles(comments) {
  const db = dbConn.db('pageturner');

  // Adjoin profile info to each comment
  const uids = comments.map((comment) => comment.uid);
  const cUsers = await db.collection('users').find({_id: {'$in': uids}}).project(
      {
        _id: 1,
        name: 1,
        profilePicture: 1,
        tag: 1,
      },
  ).toArray();
  const userMap = new Map();
  cUsers.forEach((user) => userMap.set(user._id.toString(), user));
  comments.forEach((comment, index) => comments[index].profile = userMap.get(comment.uid.toString()));

  return comments;
}

/**
 * Adjoin parent information to an array of comments
 * @param {Array} comments - comments to get parent info for
 * @return {Array} new comments
 */
async function addParents(comments) {
  const db = dbConn.db('pageturner');

  // Get all comments, books, and bookshelves that are parents of the comments
  const [commentIds, bookIds, shelfIds] = [[], [], []];
  comments.forEach((comment) => {
    if (comment.ptype && comment.ptype === 'bookshelf') {
      shelfIds.push(comment.pid);
    } else if (comment.ptype && comment.ptype === 'book') {
      bookIds.push(comment.pid);
    } else if (!comment.ptype || comment.ptype === 'comment') {
      commentIds.push(comment.pid);
    }
  });
  let [pComments, books, bookshelves] = await Promise.all([
    db.collection('comments').find({_id: {'$in': commentIds}}).toArray(),
    db.collection('volumes').find({volumeId: {'$in': bookIds}}).toArray(),
    db.collection('bookshelves').find({_id: {'$in': shelfIds}}).toArray(),
  ]);

  // Add profile info to each parent comment
  pComments = await addProfiles(pComments);

  // Add info to each comment
  const parentMap = new Map();
  pComments.forEach((comment) => parentMap.set(comment._id.toString(), comment));
  books.forEach((book) => parentMap.set(book.volumeId, book));
  bookshelves.forEach((bookshelf) => parentMap.set(bookshelf._id.toString(), bookshelf));
  comments.forEach((comment, index) => {
    if (['comment', 'book', 'bookshelf'].includes(comment.ptype) && comment.pid) {
      comments[index].parent = parentMap.get(comment.pid.toString());
    }
  });

  return comments;
}

exports.addProfiles = addProfiles;
exports.addParents = addParents;

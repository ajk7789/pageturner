/**
 * Logging middleware
 */

/**
 * Log an incoming request for debugging purposes
 *
 * @param {Object} req - HTTP request
 * @param {Object} res - HTTP response
 * @param {function} next - next middleware callback
 */
const logRequest = (req, res, next) => {
  // Log method and url
  console.log(`\nINCOMING ${req.method} REQUEST to ${req.url}`);

  // Log request body if nonempty
  if (Object.keys(req.body).length !== 0) {
    console.log(`Request Body:\n${JSON.stringify(req.body)}`);
  }

  next();
};

module.exports = {
  logRequest,
};

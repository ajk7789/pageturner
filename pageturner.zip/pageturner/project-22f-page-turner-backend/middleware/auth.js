/**
 * Authentication middleware
 *
 * Uses Sign in with Google: https://developers.google.com/identity/authentication
 */

const {OAuth2Client} = require('google-auth-library');

// Create Google authentication client
const client = new OAuth2Client(
    process.env.GAUTH_CLIENT_ID,
    process.env.GAUTH_CLIENT_SECRET,
    process.env.GAUTH_REDIRECT_URI,
    {scope:
      [
        'https://www.googleapis.com/auth/userinfo.email',
        'https://www.googleapis.com/auth/userinfo.profile',
        'offline',
      ],
    },
);

// Get database
const {dbConn} = require('../mongo');


/**
 * Authentication middleware function
 *
 *
 * @param {String} code - Authorization token
 */
async function getTokens(code) {
  const {tokens} = await client.getToken(code);
  return tokens;
}

/**
 * Authentication middleware function
 *
 * If an authentication token is present as a request header, attempt to verify it with
 * Google and attach the resulting user information to the request object
 * Adapted from: https://developers.google.com/identity/gsi/web/guides/verify-google-id-token
 *
 * @param {Object} req - HTTP request
 * @param {string} req.headers.authorization - Google authentication token
 * @param {Object} res - HTTP response
 * @param {function} next - next middleware callback
 */
const validateToken = async (req, res, next) => {
  // Delete req.user just in case it exists (prevent any possible security issues)
  delete req.user;
  let tokens = null;
  const db = dbConn.db('pageturner');

  try {
    // If user is logging in, use authorization code to generate access and refresh tokens
    if (req.headers.authorizationcode) {
      console.log('Attempting to generate tokens...');
      tokens = await getTokens(req.headers.authorizationcode);
      client.setCredentials(tokens);
      req.headers.authorization = tokens.id_token;
    }
    // If not a login, check to see if it's a refresh request (<= 5min before expiration)
    if (req.headers.refreshrequest) {
      console.log('Attempting to refresh token...');
      user = await db.collection('users').findOne({email: req.headers.refreshrequest});
      if (!user) {
        console.log('failed to find user while refreshing token');
        return res.status(401).json({message: 'Failed to find user while refreshing token'});
      }
      client.setCredentials(user.tokens);
      await client.refreshAccessToken().then(async (response) => {
        const newTokens = response.res.data;
        client.setCredentials(newTokens);
        req.headers.authorization = newTokens.id_token;
        tokens = newTokens;
      });
    }
  } catch (error) {
    console.error(`An error occurred while generating tokens for a user: ${error}`);
  }

  // Only authenticate if we got a token
  if (req.headers.authorization && req.headers.authorization !== 'null') {
    console.log('Attempting user authentication...');

    try {
      // Verify token with Google
      const ticket = await client.verifyIdToken({
        idToken: req.headers.authorization,
        audience: process.env.GAUTH_CLIENT_ID,
      });

      // Extract user's email
      const googleUserInfo = ticket.getPayload();
      user = await db.collection('users').findOne({email: googleUserInfo.email});
      // If the user doesn't exist, add them using data from google
      if (!user) {
        console.log('no user exists');
        user = { // TODO: Separate likedPosts/following/friends into separate API calls
          profilePicture: 'https://www.ssrl-uark.com/wp-content/uploads/2014/06/no-profile-image.png',
          cover: 'https://cdn-image.staticsfly.com/i/photobooks/WF327823_1-up_make_it_yours.jpg?impolicy=resize&width=960',
          tag: googleUserInfo.name.replace(' ', ''), // TODO: Ensure tag is unique
          description: 'This is my description',
          friends: [],
          following: [],
          followers: [],
          likedPosts: [],
          feed: [],
          posts: [],
          isIntroViewed: false,
          tokens: tokens,
          ...googleUserInfo,
        };
        await db.collection('users').insertOne(user).then((result) => {
          user._id = result.insertedId;
          req.user = user;
        });
      } else {
        // Every login should update access_token and refresh_token
        // Every refresh request should update access_token (maybe updates refresh token too, not sure but doesn't matter)
        if (tokens) {
          await db.collection('users').updateOne({email: googleUserInfo.email}, {$set: {tokens: tokens}});
          user.tokens = tokens;
        }
        // Attach user info to request
        req.user = user;
      }
    } catch (error) {
      console.error(`An error occurred while authenticating a user: ${error}`);
    }
  }
  next();
};

module.exports = {
  validateToken,
};

// Initialize Cloudinary
const cloudinary = require('cloudinary').v2;
cloudinary.config({
  cloud_name: 'duldq0ttg',
  api_key: '389494163191536',
  api_secret: 'QgdZgE4v_rHMH2RJt1NCMI2-Gio',
});

module.exports = cloudinary;

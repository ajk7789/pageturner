// Import for Google Books API client
const {google} = require('googleapis');

// Get database
const {dbConn} = require('./mongo');

/**
 * Promotes a URL from http to https (to avoid annoying messages in JS console)
 * @param {Object} volume db object
 * @return {Object} new volume object
 */
async function promoteURLs(volume) {
  volume.volumeInfo.imageLinks.smallThumbnail = volume.volumeInfo.imageLinks.smallThumbnail.replace(/^http/, 'https');
  volume.volumeInfo.imageLinks.thumbnail = volume.volumeInfo.imageLinks.thumbnail.replace(/^http/, 'https');
  return volume;
}

/**
 * Returns information about a volume (book)
 * @param {string} volumeId - Google Book's ID for volume
 * @return {Object} volume info
 */
async function getVolume(volumeId) {
  // First look up the volume in the db
  const volume = await dbConn.db('pageturner').collection('volumes').findOne({volumeId});
  if (volume) {
    return promoteURLs(volume);
  }

  // If it doesn't exist already, get it from Google
  const apiKey = process.env.GAUTH_API_KEY;

  // Get info about the volume
  const booksClient = google.books({version: 'v1', auth: apiKey});
  try {
    const volume = (await booksClient.volumes.get({volumeId})).data;
    await dbConn.db('pageturner').collection('volumes').insertOne({volumeId, ...volume});
    volume.volumeId = volumeId;
    return promoteURLs(volume);
  } catch (error) {
    console.error(error);
    return null;
  }
}

/**
 * Conduct search for book data given query using Google Books API
 * @param {string} query - string representation of array
 * @return {Promise<array>} - array of mapped book contents from search results
 */
async function googleBooksSearch(query) {
  const apiKey = `${process.env.GAUTH_API_KEY}`;

  // Search for book using Google Books API request
  const booksClient = google.books({version: 'v1', auth: apiKey});
  const searchResults = await booksClient.volumes.list({
    q: query,
    maxResults: 5,
  });

  // If nothing found, return empty array
  if (!searchResults.data.items?.length) {
    return [];
  }

  // Get more detailed info for the top 10 search results
  const detailedSearchResults = [];
  for (let i = 0; i < searchResults.data.items.length; i++) {
    detailedSearchResults.push(getVolume(searchResults.data.items[i].id));
  }
  return (await Promise.all(detailedSearchResults));
}

exports.getVolume = getVolume;
exports.googleBooksSearch = googleBooksSearch;

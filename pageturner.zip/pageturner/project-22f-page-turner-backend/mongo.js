/**
 * Database connection
 */

// Initialize a MongoDB client (connection pool)
const {MongoClient} = require('mongodb');
const client = new MongoClient(process.env.ATLAS_URI);

module.exports = {
  dbConn: client,
};

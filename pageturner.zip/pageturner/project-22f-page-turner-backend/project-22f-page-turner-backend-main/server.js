/**
 * Initializing the server and setting routes
 *
 * Adapted from https://www.mongodb.com/languages/mern-stack-tutorial
 */

// Get configuration
require('dotenv').config({path: './config.env'});

// Get database
const {dbConn} = require('./mongo');

// Set up Express server with CORS and JSON parsing
const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json({limit: '5mb'}));

// Initialize middleware
app.use(require('./middleware/logger').logRequest);
app.use(require('./middleware/auth').validateToken);

// Initialize routes
app.use(require('./routes/general'));
app.use(require('./routes/bookshelves'));
app.use(require('./routes/comments'));
app.use(require('./routes/user'), express.json({limit: '10mb'}));
app.use(require('./routes/books'));
app.use(require('./routes/groups'));

// Get server port from the environment or use default of 5001
const port = process.env.PORT || 5001;

// Start the server
const server = app.listen(port);

/**
 * Handle shutdowns gracefully
 */
function cleanup() {
  console.log('Shutting down...');
  server.close(() => {
    console.log('HTTP server closed');
  });
  dbConn.close();
  process.exit();
}
process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);

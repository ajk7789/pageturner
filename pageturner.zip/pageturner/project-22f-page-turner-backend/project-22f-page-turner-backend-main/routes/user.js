/**
 * User management endpoints
 */

// Create a new router for user routes
const express = require('express');
const {addProfiles, addParents} = require('../helpers');
const cloudinary = require('../cloudinary');
router = express.Router();

// Get database
const {dbConn} = require('../mongo');
const ObjectId = require('mongodb').ObjectId;

const userFields = {
  '_id': 1,
  'profilePicture': 1,
  'cover': 1,
  'tag': 1,
  'description': 1,
  'friends': 1,
  'following': 1,
  'feed': 1,
  'name': 1,
  'exp': 1,
  'likedPosts': 1,
  'posts': 1,
  'bookmarks': 1,
  'followers': 1,
  'viewedIntro': 1,
};

/**
 * POST: /user/on_login
 *
 * Upserts user data after login
 */
router.route('/user/on_login').post(async (req, res, next) => {
  try {
    if (!req.user) {
      throw new Error('User is not logged in');
    }

    const db = dbConn.db('pageturner');
    const query = {email: req.user.email}; // Identify user with this email
    const result = await db.collection('users').findOne(query);
    result.tokens = {'id_token': result.tokens.id_token, 'expiry_date': result.tokens.expiry_date}; // Don't send refresh token to client, security concern

    // Set the viewedIntro flag to true if it doesn't exist. Doesn't get returned immediately
    if (!result.viewedIntro) {
      const update = {'$set': {viewedIntro: true}};
      const options = {upsert: true};
      await db.collection('users').updateOne(query, update, options);
    }
    await res.send({result});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /user/update_profile
 *
 * Updates user profile after edits
 * TODO: set global restrictions for what's sent from profile to client. Sensitive tokens still being sent sometimes
 */
router.route('/user/update_profile').post(async (req, res, next) => {
  try {
    if (!req.user) {
      throw new Error('User is not logged in');
    }

    const editableFields = ['name', 'tag', 'description', 'profilePicture', 'cover'];
    for (const field in req.body.newProfile) {
      if (!editableFields.includes(field)) {
        delete req.body.newProfile[field];
      }
    }

    // Upload profile picture
    if (req.body.newProfile.cover) {
      const coverUploadResult = await cloudinary.uploader.upload(req.body.newProfile.cover);
      req.body.newProfile.cover = coverUploadResult.secure_url;
    }
    if (req.body.newProfile.profilePicture) {
      const profileUploadResult = await cloudinary.uploader.upload(req.body.newProfile.profilePicture);
      req.body.newProfile.profilePicture = profileUploadResult.secure_url;
    }

    const db = dbConn.db('pageturner');
    const query = {email: req.user.email}; // Identify user with this email

    // Update with all editable fields sent with the new profile
    const update = {'$set': req.body.newProfile}; // Update all fields found in req.body.newProfile
    const options = {upsert: true}; // Update or insert if no such user exists
    await db.collection('users').updateOne(query, update, options);

    // Send the updated record back (in case update failed)
    const result = await db.collection('users').findOne(query);
    await res.send({result});
  } catch (error) {
    console.error(error);
    next();
  }
});

router.route('/user/refresh_token').post(async (req, res, next) => {
  try {
    if (!req.user) {
      throw new Error('User is not logged in');
    }

    const db = dbConn.db('pageturner');
    const query = {email: req.user.email}; // Identify user with this email
    const queryRes = await db.collection('users').findOne(query);
    result = {tokens: {id_token: queryRes.tokens.id_token, expiry_date: queryRes.tokens.expiry_date}};
    await res.send({result});
  } catch (error) {
    console.error(error);
    next();
  }
});

router.route('/user/send_feedback').post(async (req, res, next) => {
  try {
    if (!req.body.feedbackText || !req.body.user) {
      throw new Error('Request is missing feedbackText or user');
    }
    const db = dbConn.db('pageturner');
    // Insert feedback text and user into feedback collection
    const result = await db.collection('feedback').insertOne({feedbackText: req.body.feedbackText, user: req.body.user});
    await res.send({result});
  } catch (error) {
    console.error(error);
    next();
  }
});


/**
 * POST: /user/get_profile
 *
 * Fetches one user profile or group profile based on id
 * TODO: Abstract equivalent code in other endpoints
 */
router.route('/user/get_profile').post(async (req, res, next) => {
  try {
    if (!req.body.uid) {
      throw new Error('Request is missing uid');
    }
    req.body.uid = new ObjectId(req.body.uid);

    const db = dbConn.db('pageturner');
    const query = {_id: req.body.uid}; // Identify user with this email
    const projectFields = userFields;
    if (req.user && req.user._id.toString() === req.body.uid.toString()) { // If the user is requesting their own profile, send all fields
      projectFields['tokens.id_token'] = 1;
      projectFields['tokens.expiry_date'] = 1;
      projectFields['notifications'] = 1;
      projectFields['email'] = 1;
    }

    // Send the user profile back
    let result = await db.collection('users').findOne(query, {projection: projectFields});
    if (result == null) { // if the id doesn't belong to a user, check if it belongs to a group
      result = await db.collection('groups').findOne(query);
    }
    await res.send({result});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /user/get_basic_profile
 *
 * Fetches id, name, tag, and profile picture of user
 */
router.route('/user/get_basic_profile').post(async (req, res, next) => {
  try {
    if (!req.body.uid) {
      throw new Error('Request is missing uid');
    }
    req.body.uid = new ObjectId(req.body.uid);

    const db = dbConn.db('pageturner');
    const query = {_id: req.body.uid}; // Identify user with this email
    // Send the user profile back
    const result = await db.collection('users').findOne(query, {projection: {
      _id: 1,
      name: 1,
      tag: 1,
      profilePicture: 1,
    }});
    await res.send({result});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /user/get_profiles_from_ids
 *
 * Fetches a list of user profiles from an array of string ids
 */
router.route('/user/get_profiles_from_ids').post(async (req, res, next) => {
  try {
    if (!req.body.profileIds) {
      throw new Error('Request is missing profileIds');
    }
    const db = dbConn.db('pageturner');
    // Convert ids to ObjectIds
    const profileIds = req.body.profileIds.map((id) => new ObjectId(id));
    const projectFields = {
      _id: 1,
      name: 1,
      tag: 1,
      profilePicture: 1,
    };
    // For each string id in get_profiles_from_ids, fetch the profile and add it to the profiles array
    const profiles = await db.collection('users').find({_id: {'$in': profileIds}}, {projection: projectFields}).toArray();
    await res.send({profiles});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
   * POST: /user/get_posts
   *
   * Returns a user's created posts
   *
   */
router.route('/user/get_posts').post(async (req, res, next) => {
  try {
    // Return comment IDs from logged in user's posts array
    const db = dbConn.db('pageturner');
    const uid = new ObjectId(req.body.uid);
    // Query comments collection to find all posts with corresponding uid
    let posts = await db.collection('comments')
        .find({uid: uid})
        .sort({'metadata.timestamp': -1})
        .toArray();
    if (posts) {
      posts = await addParents(posts);
      posts = await addProfiles(posts);
    }
    await res.send({posts: posts});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
   * POST: /user/get_post_count
   *
   * Returns the number of posts belonging to a club or user
   *
   */
router.route('/user/get_post_count').post(async (req, res, next) => {
  try {
    if (!req.body.id || !req.body.type) {
      throw new Error('Request requires id and type');
    }
    // Return comment IDs from logged in user's posts array
    const db = dbConn.db('pageturner');
    const type = req.body.type;
    let count = 0;

    if (type == 'user') {
      // Query comments collection to count the number of posts with corresponding id
      count = await db.collection('comments')
          .countDocuments({uid: new ObjectId(req.body.id)});
    } else if (type == 'club') {
      // Query comments collection to count the number of posts with scope having corresponding id
      count = await db.collection('comments')
          .countDocuments({scope: req.body.id});
    }
    await res.send({count: count});
  } catch (error) {
    console.error(error);
    next();
  }
});


/**
 * POST: /user/get_bookmarks
 *
 * Gets a user's list of saved posts
 */
router.route('/user/get_bookmarks').post(async (req, res, next) => {
  try {
    const uid = new ObjectId(req.body.uid);
    const db = dbConn.db('pageturner');
    const currentUser = await db.collection('users').findOne({_id: uid});
    const bookmarks = currentUser.bookmarks || [];

    await res.send({bookmarks});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /user/get_liked_posts
 *
 * Returns a user's created posts
 *
 */
router.route('/user/get_liked_posts').post(async (req, res, next) => {
  try {
    // // Require user is logged in
    // if (!req.user) {
    //   throw new Error('Unauthenticated request');
    // }
    const uid = new ObjectId(req.body.uid);

    // Return comment IDs from logged in user's posts array
    const db = dbConn.db('pageturner');
    const currentUser = await db.collection('users').findOne({_id: uid});
    const likedPosts = currentUser.likedPosts;

    await res.send({likedPosts});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
   * GET: /user/feed
   *
   * Returns a user's feed
   *
   *
   */
router.route('/user/get_feed').post(async (req, res, next) => {
  try {
    // Require user is logged in
    if (!req.user) {
      throw new Error('Unauthenticated request');
    }

    // Return comment IDs from logged in user and users from friends & following list
    const db = dbConn.db('pageturner');
    const currentUser = await db.collection('users').findOne({_id: req.user._id});
    const feedIds = currentUser.feed;

    // Select the 20 comments on the specified page
    let feed = await db.collection('comments')
        .find({_id: {$in: feedIds}})
        .sort({'metadata.timestamp': -1})
        .skip(20*req.body.pageNumber)
        .limit(20)
        .toArray();

    // Add profile and parent info to comments
    feed = await addProfiles(feed);
    feed = await addParents(feed);
    await res.send({feed});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /user/update_bookmarks
 * Like/Unlike a post
 *
 * TODO: Might be a good idea to fetch the actual profile and count to ensure it's accurate, but not sure it's worth the extra query yet
 * Note: Needs to store strings, not Object Ids, in the array
 */
router.route('/user/update_bookmarks').post(async (req, res, next) => {
  try {
    // Require pid was provided
    if (!req.user) {
      throw new Error('User is not logged in.');
    }
    const db = dbConn.db('pageturner');
    const currentUser = await db.collection('users').findOne({_id: req.user._id});
    const commentId = req.body.cid; // Note: Keep as string for easier search and deletion

    if (!currentUser.bookmarks) {
      currentUser.bookmarks = [];
    }

    if (currentUser.bookmarks.includes(commentId)) { // Use the string, not the object, for comparison
      // Find comment in user's bookmarks array and remove it
      const index = currentUser.bookmarks.indexOf(commentId);
      if (index > -1) {
        currentUser.bookmarks.splice(index, 1);
      }
    } else {
      currentUser.bookmarks.push(commentId);
    }
    // Update user's bookmarks array
    await db.collection('users').updateOne({_id: req.user._id}, {$set: {bookmarks: currentUser.bookmarks}});

    await(res.send({bookmarks: currentUser.bookmarks}));
  } catch (error) {
    console.log(error);
    next();
  }
});

/**
 * POST: /user/follower/add
 *
 * Add a user to this user's list of people they follow
 */
router.route('/user/follower/add').post(async (req, res, next) => {
  try {
    req.body.uid = new ObjectId(req.body.uid);
    // Require user is logged in
    if (!req.user) {
      throw new Error('Unauthenticated request');
    }

    // Require friend id was provided
    if (!req.body.uid) {
      throw new Error('Request is missing the desired user\'s id');
    }

    // Require that friend exists in the database & is unique
    const db = dbConn.db('pageturner');
    const userMatches = await db.collection('users').count({_id: req.body.uid});
    if (userMatches != 1) {
      throw new Error(`The provided email matches ${userMatches} users`);
    }

    // Add the friend
    console.log('Requirements satisfied, proceeding to update user record...');
    await db.collection('users').updateOne(
        {email: req.user.email},
        {'$addToSet': {following: req.body.uid}},
    );
    await db.collection('users').updateOne(
        {_id: req.body.uid},
        {'$addToSet': {followers: req.user._id}},
    );
    console.log('User record updated');

    await res.send({success: true});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /user/follower/remove
 *
 * Remove a user from this user's list of people they follow
 */
router.route('/user/follower/remove').post(async (req, res, next) => {
  try {
    req.body.uid = new ObjectId(req.body.uid); // id of user losing the follower
    // Require user is logged in
    if (!req.user) {
      throw new Error('Unauthenticated request');
    }

    // Require follower-loser id was provided
    if (!req.body.uid) {
      throw new Error('Request is missing the desired user\'s id');
    }

    // Require that folower exists in the database & is unique
    const db = dbConn.db('pageturner');
    const userMatches = await db.collection('users').count({_id: req.body.uid});
    if (userMatches != 1) {
      throw new Error(`The provided email matches ${userMatches} users`);
    }

    // Remove the follower
    console.log('Requirements satisfied, proceeding to update user record...');
    await db.collection('users').updateOne(
        {email: req.user.email},
        {'$pull': {following: req.body.uid}},
    );
    await db.collection('users').updateOne(
        {_id: req.body.uid},
        {'$pull': {followers: req.user._id}},
    );
    console.log('User record updated');

    await res.send({success: true});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /user/get_following
 *
 * Gets the accounts a user follows
 */
router.route('/user/get_following').post(async (req, res, next) => {
  try {
    const db = dbConn.db('pageturner');
    const uid = new ObjectId(req.body.uid);
    const followingIds = (await db.collection('users').findOne({_id: uid})).following;
    const following = await db.collection('users').find({'_id': {'$in': followingIds}}).project(
        {
          _id: 1,
          name: 1,
          tag: 1,
        },
    ).toArray();

    await res.send(following);
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /user/get_followers
 *
 * Gets a user's followers
 */
router.route('/user/get_followers').post(async (req, res, next) => {
  try {
    const db = dbConn.db('pageturner');
    const uid = new ObjectId(req.body.uid);
    const followerIds = (await db.collection('users').findOne({_id: uid})).followers;
    const followers = await db.collection('users').find({'_id': {'$in': followerIds}}).project(
        {
          _id: 1,
          name: 1,
          tag: 1,
        }).toArray();

    await res.send(followers);
  } catch (error) {
    console.error(error);
    next();
  }
});

module.exports = router;

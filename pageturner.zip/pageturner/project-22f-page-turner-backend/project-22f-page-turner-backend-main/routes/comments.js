/**
 * Comment system endpoints
 */

// Create a new router for comment routes
const express = require('express');
// const {getVolume} = require('../gbooks');
const {addProfiles, addParents} = require('../helpers');
router = express.Router();

// Get database
const {dbConn} = require('../mongo');
const ObjectId = require('mongodb').ObjectId;

/**
 * GET: /comments/replies
 *
 * Gets all comments with the specified parent ID
 *
 * @param req.params.pid - parent ID
 */
router.route('/comments/replies/:pid').get(async (req, res, next) => {
  try {
    if (!req.params.pid) {
      throw new Error('Request is missing pid');
    }

    // If the pid is 24 characters it can be converted to an object ID, otherwise leave as a string
    if (typeof(req.params.pid) === 'string' && req.params.pid.length === 24) {
      req.params.pid = new ObjectId(req.params.pid);
    }

    // We can return the entire contents of each comment document as there's no sensitive info
    const db = dbConn.db('pageturner');
    let replies = await db.collection('comments').find({pid: req.params.pid}).toArray();

    // Add profile and parent info to comments
    replies = await addProfiles(replies);
    replies = await addParents(replies);

    await res.send({replies});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /comments/get_comment
 *
 * Gets a comment with a given commentId
 *
 * @param req.body.id - ID of parent
 */
router.route('/comments/get_comment').post(async (req, res, next) => {
  try {
    // Require pid was provided
    if (!req.body.id) {
      throw new Error('Request is missing comment id');
    }

    req.body.id = new ObjectId(req.body.id);

    // NOTE: for now we won't check if the user is authorized to view
    // comments on the object, but we need to change this in the future
    // Use code from /comments/post_comment to do this

    const db = dbConn.db('pageturner');
    let comment = await db.collection('comments').findOne({_id: req.body.id});
    if (!comment) {
      // If comment doesn't exist and user's logged in, remove it from likedPosts, bookmarks, and feed
      if (req.user) {
        await db.collection('users').updateOne(
            {_id: req.user._id},
            {$pull: {likedPosts: req.body.id.toString(), bookmarks: req.body.id.toString(), feed: req.body.id}},
        );
      }
      await res.send({comment: null});
      return;
    }
    [comment] = await addParents([comment]);
    await res.send({comment: comment});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /comments/delete_comment
 *
 * Gets a comment with a given commentId
 * TODO: Check that the user is authorized to delete the comment
 *
 * @param req.body.id - ID of parent
 */
router.route('/comments/delete_comment').post(async (req, res, next) => {
  try {
    // Require id was provided
    if (!req.body.id) {
      throw new Error('Request is missing comment id');
    }
    if (!req.user) {
      throw new Error('User is not logged in.');
    }

    req.body.id = new ObjectId(req.body.id);

    const db = dbConn.db('pageturner');
    // Delete from the comments collection
    await db.collection('comments').deleteOne({_id: req.body.id});

    await res.send({success: true});
  } catch (error) {
    console.error(error);
    next();
  }
});


/**
 * POST: /comments/update_likes
 * Like/Unlike a post
 *
 * TODO: Might be a good idea to fetch the actual profile and count to ensure it's accurate, but not sure it's worth the extra query yet
 * Note: Needs to store strings, not Object Ids, in the array
 */
router.route('/comments/update_likes').post(async (req, res, next) => {
  try {
    // Require pid was provided
    if (!req.user) {
      throw new Error('User is not logged in.');
    }
    const db = dbConn.db('pageturner');
    const currentUser = await db.collection('users').findOne({_id: req.user._id});
    const commentId = req.body.cid; // Note: Keep as string for easier search and deletion

    if (!currentUser.likedPosts) {
      currentUser.likedPosts = [];
    }

    if (currentUser.likedPosts.includes(commentId)) { // Use the string, not the object, for comparison
      // Find comment in user's likedPosts array and remove it
      const index = currentUser.likedPosts.indexOf(commentId);
      if (index > -1) {
        currentUser.likedPosts.splice(index, 1);
        // Find comment in comments collection and decrease its likes by 1
        await db.collection('comments').updateOne({_id: new ObjectId(commentId)}, {$inc: {'metadata.likes': -1}});
      }
    } else {
      currentUser.likedPosts.push(commentId);
      // Find comment in comments collection and increase its likes by 1
      await db.collection('comments').updateOne({_id: new ObjectId(commentId)}, {$inc: {'metadata.likes': 1}});
    }
    // Update user's likedPosts array
    await db.collection('users').updateOne({_id: req.user._id}, {$set: {likedPosts: currentUser.likedPosts}});

    await(res.send({likedPosts: currentUser.likedPosts}));
  } catch (error) {
    console.log(error);
    next();
  }
});

/**
 * POST: /comments/post_comment
 *
 * Gets all comments on the requested parent object
 * Requires user is logged in
 *
 * @param req.body.scope - scope to comment on
 * @param req.body.pid - ID of parent object to comment on
 * @param req.body.text - Content of the comment
 */
router.route('/comments/post_comment').post(async (req, res, next) => {
  try {
    // Require user is logged in
    if (!req.user) {
      throw new Error('Unauthenticated request');
    }

    // Require scope was provided
    if (!req.body.scope) {
      throw new Error('Request is missing scope');
    }

    // Require text was provided
    if (!req.body.text) {
      throw new Error('Request is missing text');
    }

    // Convert pid from string to ObjectId if not a review
    if (req.body.ptype !== 'book' && req.body.pid) {
      req.body.pid = new ObjectId(req.body.pid);
    }

    // Validate parent type and ensure object exists
    const db = dbConn.db('pageturner');

    // NOTE: for now we won't check if the user is authorized to make
    // comments on the object, but we need to change this in the future
    const commentData = {
      uid: req.user._id,
      displayName: req.user.tag, // TODO: different display name?
      username: req.user.name,
      avatar: req.user.picture,
      // text: req.body.text,
      metadata: {
        likes: 0,
        replies: 0,
        retweets: 0,
        timestamp: new Date(),
      },
      ...req.body,
    };

    if (req.body.scope !== 'global') {
      // Fetch the bookclub title and add subtext
      const bookclub = await db.collection('groups').findOne({_id: new ObjectId(req.body.scope)});
      commentData.subtext = 'Posted in ' + bookclub.name;
    }

    // Add the comment
    const result = await db.collection('comments').insertOne(commentData);
    const commentId = result.insertedId;

    // Add the comment ID to the user's feed array
    await db.collection('users').updateOne({_id: new ObjectId(req.user._id)}, {$push: {feed: commentData._id}});
    if (commentData.ptype !== 'book' && commentData.pid) {
      // Increment the parent comment's replies count
      await db.collection('comments').updateOne({_id: commentData.pid}, {$inc: {'metadata.replies': 1}});
    }
    if (commentData.scope === 'global') {
      // Fetch the followers array from the current user, and post the comment to the feed of all followers
      const user = await db.collection('users').findOne({_id: req.user._id});
      for (const follower of user.followers) {
        await db.collection('users').updateOne({_id: follower}, {$push: {feed: commentData._id}});
      }
    } else {
      // It's a book club, so fetch the club, and post the comment to the feed of all members
      const bookclub = await db.collection('groups').findOne({_id: new ObjectId(commentData.scope)});
      for (const member of bookclub.members) {
        await db.collection('users').updateOne({_id: new ObjectId(member)}, {$push: {feed: commentData._id}});
      }
    }
    res.status(200).json({commentId});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /comments/update_likes
 * Like/Unlike a post
 */
router.route('/comments/update_likes').post(async (req, res, next) => {
  try {
    // Require pid was provided
    if (!req.user) {
      throw new Error('User is not logged in.');
    }
    const commentId = new ObjectId(req.body._id);

    const db = dbConn.db('pageturner');
    const currentUser = await db.collection('users').findOne({_id: req.user._id});
    // const comment = await db.collection('comments').findOne({_id: commentId});

    if (!currentUser.likedPosts) {
      currentUser.likedPosts = [];
    }
    if (currentUser.likedPosts.includes(commentId)) {
      // Find comment in user's likedPosts array and remove it
      const index = currentUser.likedPosts.indexOf(commentId);
      if (index > -1) {
        currentUser.likedPosts.splice(index, 1);
      }
    } else {
      currentUser.likedPosts.push(commentId);
    }
    // Update user's likedPosts array
    await db.collection('users').updateOne({_id: req.user._id}, {$set: {likedPosts: currentUser.likedPosts}});
  } catch (error) {
    console.log(error);
    next();
  }
});

/**
 * Get: /notifications/get_notification
 * Receive notification from db
 */
router.get('/notifications/get_notifications', async (req, res, next) => {
  try {
    if (!req.user) {
      throw new Error('User is not logged in.');
    }
    const db = dbConn.db('pageturner');
    const currentUser = await db.collection('users').findOne({_id: req.user._id});

    if (!currentUser) {
      throw new Error('User not found');
    }

    const returnedNotifications = [];
    // Add comment data to currentUser.notifications
    for (const notification of currentUser.notifications) {
      if (notification.type === 'like' || notification.type === 'reply') {
        let comment = await db.collection('comments').findOne({_id: new ObjectId(notification.cId)});
        // If the comment doesn't exist, delete the notification
        if (!comment) {
          db.collection('users').updateOne({_id: req.user._id}, {$pull: {notifications: {notificationId: notification.notificationId}}});
        } else {
          [comment] = await addParents([comment]);
          [comment] = await addProfiles([comment]);
          notification.comment = comment;
          returnedNotifications.push(notification);
        }
      } else {
        returnedNotifications.push(notification);
      }
    }

    return res.send({notifications: returnedNotifications});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /notifications/post_notification
 * Sends notification to user
 */
router.route('/notifications/post_notification').post(async (req, res, next) => {
  try {
    if (!req.user) {
      throw new Error('User is not logged in.');
    }

    if (String(req.user._id) === String(req.body.recipientId)) { // Don't send notification to self
      return res.status(200).json({success: true});
    }
    // Validate parent type and ensure object exists
    const db = dbConn.db('pageturner');

    const recipientId = req.body.recipientId;
    const cId = req.body.cId;
    const commenterId = req.body.commenterId;
    const isViewed = req.body.isViewed;
    const type = req.body.type;

    if (!recipientId || !cId || !commenterId) {
      throw new Error('Recipient ID, cId, and commenter ID are required');
    }

    const notification = {
      notificationId: new ObjectId(),
      cId: cId,
      commenterId: commenterId,
      isViewed: isViewed,
      type: type,
      timestamp: new Date(),
    };

    const result = await db.collection('users').updateOne({_id: new ObjectId(recipientId)}, {$push: {notifications: notification}});

    if (result.modifiedCount === 1) {
      return res.status(200).json({success: true});
    } else {
      throw new Error('Failed to update user notifications');
    }
  } catch (error) {
    console.error(error);
    next();
  }
});

router.route('/notifications/update_notification').post(async (req, res, next) => {
  try {
    if (!req.user) {
      throw new Error('User is not logged in.');
    }
    const db = dbConn.db('pageturner');

    // fetch the current user and update all objects in the notification array to have isViewed = true
    const currentUser = await db.collection('users').findOne({_id: new ObjectId(req.user._id)});
    const notifications = currentUser.notifications;
    if (!notifications) {
      return res.status(200).send('No notifications');
    }
    await db.collection('users').findOneAndUpdate(
        {_id: new ObjectId(req.user._id)},
        {$set: {notifications: notifications.map((notification) => ({
          ...notification,
          isViewed: true,
        }))},
        },
    );

    return res.status(200).send('Notifications updated');
  } catch (error) {
    console.error(error);
    next();
  }
});

module.exports = router;

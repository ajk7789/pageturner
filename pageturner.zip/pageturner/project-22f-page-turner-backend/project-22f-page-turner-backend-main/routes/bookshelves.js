/**
 * Bookshelf system endpoints
 */

// Create a new router for bookshelf routes
const express = require('express');
router = express.Router();

// Get database
const {dbConn} = require('../mongo');
const ObjectId = require('mongodb').ObjectId;

/**
 * POST: /bookshelves/create
 *
 * Create a bookshelf as a user or as an admin of a group
 * Requires user is logged in
 * If ownerType is 'user', the bookshelf is created under the current user, and we
 * require that ownerId matches the user's ID
 * If ownerType 'group', the bookshelf is created under the specified group, and we
 * require that the logged in user is an admin of the group specified by ownerId
 *
 * @param req.body.name - name of bookshelf
 * @param ownerId - ID of owner
 * @param ownerType - 'user' or 'group'
 */
router.route('/bookshelves/create').post(async (req, res, next) => {
  try {
    // Require user is logged in
    if (!req.user) {
      throw new Error('Unauthenticated request');
    }

    // Require name was provided
    if (!req.body.name) {
      throw new Error('Request is missing bookshelf name');
    }

    // Require ownerId was provided
    if (!req.body.ownerId) {
      throw new Error('Request is missing ownerId');
    }

    // Require ownerType was provided
    if (!req.body.ownerType) {
      throw new Error('Request is missing ownerType');
    }

    req.body.ownerId = new ObjectId(req.body.ownerId);

    // Enforce permissions
    const db = dbConn.db('pageturner');
    const newId = new ObjectId();
    // Create the bookshelf
    await db.collection('bookshelves').insertOne({
      _id: newId,
      ownerId: req.user._id,
      ownerType: req.body.ownerType,
      name: req.body.name,
      books: [],
    });
    await res.send({_id: newId});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /bookshelves/get_bookshelf
 *
 * Gets books in the requested bookshelf
 *
 * @param req.body.shelfId - ID of bookshelf
 */
router.route('/bookshelves/get_bookshelf').post(async (req, res, next) => {
  try {
    // Require shelfId was provided
    if (!req.body.shelfId) {
      throw new Error('Request is missing shelfId');
    }

    // NOTE: for now we won't check if the user is authorized to view
    // the bookshelf, but we need to change this in the future
    req.body.shelfId = new ObjectId(req.body.shelfId);
    const db = dbConn.db('pageturner');
    const bookshelf = await db.collection('bookshelves').findOne({_id: req.body.shelfId});
    await res.send({bookshelf});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /bookshelves/get_bookshelf
 *
 * Gets books in the requested bookshelf
 *
 * @param req.body.shelfId - ID of bookshelf
 * @param req.body.newBookshelf - ID of bookshelf
 */
router.route('/bookshelves/update_bookshelf').post(async (req, res, next) => {
  try {
    if (!req.user) {
      throw new Error('User is not logged in');
    }
    // Require shelfId was provided
    if (!req.body.shelfId) {
      throw new Error('Request is missing shelfId');
    }

    // NOTE: for now we won't check if the user is authorized to view
    // the bookshelf, but we need to change this in the future
    req.body.shelfId = new ObjectId(req.body.shelfId);
    const db = dbConn.db('pageturner');

    if (req.body.newBookshelf.books.length == 0) {
      // Delete the bookshelf with shelfId from the bookshelves collection
      await db.collection('bookshelves').deleteOne({_id: req.body.shelfId});
    } else {
      // Update the title and books array of the bookshelf with shelfId
      await db.collection('bookshelves').updateOne({_id: req.body.shelfId}, {$set: {name: req.body.newBookshelf.name, books: req.body.newBookshelf.books}});
    }
    await res.send({success: true});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /bookshelves/get_bookshelves
 *
 * Gets bookshelves attached to an owner (user or group)
 *
 * @param req.body.ownerId - ID of owner
 * @param req.body.ownerType - 'user' or 'group'
 */
router.route('/bookshelves/get_bookshelves').post(async (req, res, next) => {
  try {
    // Require ownerId was provided
    if (!req.body.ownerId) {
      throw new Error('Request is missing ownerId');
    }
    const db = dbConn.db('pageturner');
    req.body.ownerId = new ObjectId(req.body.ownerId);
    const bookshelves = await db.collection('bookshelves')
        .find({ownerId: req.body.ownerId})
        .toArray();
    await res.send({bookshelves});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /bookshelves/modify
 *
 * Add or remove a book from a bookshelf or edit its name & description
 * Requires user is logged in, owns bookshelf or is an admin for the group that owns the bookshelf
 *
 * @param req.body.shelfId - ID of bookshelf
 * @param req.body.op - 'add', 'remove', 'edit'
 * @param req.body.bookId - ID of book if 'add' or 'remove'
 * @param req.body.name - new name of bookshelf if 'edit'
 * @param req.body.description - new description for bookshelf if 'edit'
 */
router.route('/bookshelves/modify').post(async (req, res, next) => {
  try {
    // Require user is logged in
    if (!req.user) {
      throw new Error('Unauthenticated request');
    }

    // Require shelfId was provided
    if (!req.body.shelfId) {
      throw new Error('Request is missing shelfId');
    }

    // Require a valid operation was specified
    if (req.body.op !== 'add' && req.body.op !== 'remove' && req.body.op !== 'edit') {
      throw new Error('Request does not specify a valid operation');
    }

    // Require bookId was provided if adding or removing
    if (req.body.op !== 'edit' && !req.body.bookId) {
      throw new Error('Request is missing bookId');
    }

    // Require name and description were provided if editing
    if (req.body.op === 'edit' && (!req.body.name || !req.body.description)) {
      throw new Error('Request is missing bookshelf name and description');
    }

    // The user must own the bookshelf, or be an admin for the group that owns the bookshelf
    const db = dbConn.db('pageturner');
    req.body.shelfId = new ObjectId(req.body.shelfId);
    const bookshelf = await db.collection('bookshelves').findOne({_id: req.body.shelfId});
    if (!bookshelf) {
      throw new Error('No such bookshelf exists');
    }

    if (bookshelf.ownerType == 'user' && bookshelf.ownerId.toString() !== req.user._id.toString()) {
      throw new Error('The user is unauthorized to change this bookshelf');
    } else if (bookshelf.ownerType == 'group') {
      const group = await db.collection('groups').findOne({_id: bookshelf.ownerId});
      if (!group) {
        throw new Error('Unable to locate bookshelf owner');
      }
      if (!group.admins.includes(req.user._id)) {
        throw new Error('The user is unauthorized to change this bookshelf');
      }
    }

    // Update the bookshelf
    let update = null;
    switch (req.body.op) {
      case 'add':
        update = {'$addToSet': {books: req.body.bookId}};
        break;
      case 'remove':
        update = {'$pull': {books: req.body.bookId}};
        break;
      case 'edit':
        update = {name: req.body.name, description: req.body.description};
        break;
    }
    await db.collection('bookshelves').updateOne({_id: req.body.shelfId}, update);
    await res.send({success: true});
  } catch (error) {
    console.error(error);
    next();
  }
});

module.exports = router;

/**
 * Endpoints for putting a client message in DB & getting the last message in all caps
 *
 * Adapted from https://www.mongodb.com/languages/mern-stack-tutorial
 */

const express = require('express');
const googleBooksSearch = require('../gbooks').googleBooksSearch;

// Control requests starting with path /books.
const booksRoute = express.Router();

//
booksRoute.route('/books/search/:query').get(async function(req, res) {
  res.json(await googleBooksSearch(req.params.query));
});

module.exports = booksRoute;

/**
 * General endpoints (focus on site-wide content)
 * E.x. search, feed, trending
 */

// Create a new router for user routes
const express = require('express');
router = express.Router();

// Get database
const {dbConn} = require('../mongo');

// Google books search helper
const {getVolume, googleBooksSearch} = require('../gbooks');
const {addProfiles, addParents} = require('../helpers');

/**
 * POST: /search
 *
 * Site-wide search to simplify navigation
 *
 * @param req.body.query - user input to search for
 */
router.route('/search/:searchString').get(async (req, res, next) => {
  try {
    // Prepare searchString by removing quotes, escaping special characters
    let searchString = req.params.searchString;
    searchString = searchString.replace(/^["'](.+(?=["']$))["']$/, '$1');
    searchString = searchString.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

    // Use regular expressions to perform a case-insensitive search
    const searchRegex = new RegExp(searchString, 'i');

    const db = dbConn.db('pageturner');
    let [users, groups, comments, bookshelves] = await Promise.all([
      // Search users
      db.collection('users').find({
        $or: [
          {name: searchRegex},
          {given_name: searchRegex},
          {family_name: searchRegex},
          {description: searchRegex},
          {tag: searchRegex},
        ],
      }).limit(15).toArray(),

      // Search groups
      db.collection('groups').find({
        $or: [
          {name: searchRegex},
          {description: searchRegex},
          {tag: searchRegex},
        ],
      }).limit(15).toArray(),

      // Search comments
      db.collection('comments').find({
        $or: [
          {text: searchRegex},
        ],
      }).sort({'metadata.likes': -1}).limit(15).toArray(),

      // Search bookshelves
      db.collection('bookshelves').find({
        $or: [
          {name: searchRegex},
          {description: searchRegex},
        ],
      }).limit(15).toArray(),
    ]);

    // Add profile info to comments
    comments = await addProfiles(comments);

    await res.send({users, groups, comments, bookshelves});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /search_books
 *
 * Book search
 *
 * @param req.body.query - user input to search for
 */
router.route('/search_books/:searchString').get(async (req, res, next) => {
  try {
    // Search books
    const books = await googleBooksSearch(req.params.searchString);
    await res.send({books});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * Get: /book/:bookId
 *
 * Get information about a single book
 *
 * @param req.params.bookId - the ID of the book to get info for
 */
router.route('/books/:bookId').get(async (req, res, next) => {
  try {
    // Get book information from Google Books
    const volume = await getVolume(req.params.bookId);
    await res.send({bookId: req.params.bookId, ...volume.volumeInfo});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * GET: /general/get_trends
 *
 * Gets trends stored in the database
 * TODO: Make real trends in the database
 *
 */
router.route('/get_trends').get(async (req, res, next) => {
  try {
    const db = dbConn.db('pageturner');
    // const trends = await db.collection('trends').find().toArray();
    const trends = await db.collection('comments')
        .find({scope: 'global'})
        .sort({'metadata.likes': -1})
        .limit(4)
        .toArray();
    await res.send({trends: trends});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * GET: /get_global_feed
 *
 * Returns a feed of posts
 * Want: Only public posts. Preference for recent posts. Preference for popular posts
 *
 */
router.route('/get_global_feed').post(async (req, res, next) => {
  try {
    const db = dbConn.db('pageturner');
    // Log a timer to see how long this takes
    let feed = await db.collection('comments')
        .find({scope: 'global'})
        .sort({'metadata.timestamp': -1})
        .skip(10*req.body.pageNumber)
        .limit(10)
        .toArray();

    // Add profile and parent info to comments
    feed = await addProfiles(feed);
    feed = await addParents(feed);
    await res.send({feed});
  } catch (error) {
    console.error(error);
    next();
  }
});


/**
 * GET: /reviews
 *
 * Gets all reviews of a book
 *
 * @param req.params.bookId - ID of book
 */
router.route('/reviews/:bookId').get(async (req, res, next) => {
  try {
    // Reviews are all comments where pid = bookId and rating exists
    const db = dbConn.db('pageturner');
    let reviews = await db.collection('comments').find({pid: req.params.bookId, rating: {'$exists': true}}).toArray();

    // Add profile info to reviews
    reviews = await addProfiles(reviews);

    await res.send({reviews});
  } catch (error) {
    console.error(error);
    next();
  }
});

module.exports = router;

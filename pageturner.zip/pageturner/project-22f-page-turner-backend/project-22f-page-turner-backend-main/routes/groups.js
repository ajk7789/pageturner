/**
 * Group system endpoints
 */

// Create a new router for group routes
const express = require('express');
router = express.Router();

// Get database
const {dbConn} = require('../mongo');
const ObjectId = require('mongodb').ObjectId;
const {addProfiles, addParents} = require('../helpers');

/**
 * POST: groups/get_book_clubs/:uid
 *
 * Gets all the book clubs that a user is a member of
 */
router.route('/groups/get_book_clubs').post(async (req, res, next) => {
  try {
    if (!req.body.uid) {
      throw new Error('Request is missing uid');
    }
    req.body.uid = new ObjectId(req.body.uid);
    const db = dbConn.db('pageturner');
    const result = await db.collection('groups').find({members: String(req.body.uid)}).toArray();
    await res.send({result});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: groups/get_book_club
 *
 * Gets data for one book club
 */
router.route('/groups/get_book_club').post(async (req, res, next) => {
  try {
    if (!req.body.clubId) {
      throw new Error('Request is missing club id');
    }
    req.body.clubId = new ObjectId(req.body.clubId);
    const db = dbConn.db('pageturner');
    const result = await db.collection('groups').findOne({_id: req.body.clubId});
    await res.send({result});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * GET: groups/get_top_clubs
 *
 * Gets the top 4 public book clubs
 */
router.route('/groups/get_top_clubs').get(async (req, res, next) => {
  try {
    const db = dbConn.db('pageturner');
    const result = await db.collection('groups').aggregate(
        [
          {
            $project: {
              _id: 1,
              name: 1,
              tag: 1,
              members: 1,
              banner_picture: 1,
              description: 1,
              admins: 1,
              bookshelves: 1,
              creator_id: 1,
              posts: 1,
              num_members: {$size: '$members'},
            },
          },
          {
            $group: {
              _id: '$_id',
              name: {$first: '$name'},
              tag: {$first: '$tag'},
              banner_picture: {$first: '$banner_picture'},
              description: {$first: '$description'},
              admins: {$first: '$admins'},
              bookshelves: {$first: '$bookshelves'},
              creator_id: {$first: '$creator_id'},
              posts: {$first: '$posts'},
              num_members: {$sum: {$size: '$members'}},
            },
          },
          {
            $sort: {num_members: -1},
          },
          {
            $limit: 4,
          },
        ]).toArray();
    await res.send({result});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: groups/change_member
 *
 * Adds/removes a user from a book club
 */
router.route('/groups/change_member').post(async (req, res, next) => {
  try {
    if (!req.user) {
      throw new Error('User is not logged in');
    }
    if (!req.body.clubId) {
      throw new Error('Request is missing club id');
    }
    req.body.clubId = new ObjectId(req.body.clubId);
    const db = dbConn.db('pageturner');
    const club = await db.collection('groups').findOne({_id: req.body.clubId});
    // If user is already a member, remove them from the members array
    if (club.members.includes(String(req.user._id))) {
      club.members = club.members.filter((member) => member !== String(req.user._id));
    } else {
      club.members.push(String(req.user._id));
    }
    // Update the club with the new members array
    await db.collection('groups').replaceOne({_id: req.body.clubId}, club);

    await res.send({club: club});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: groups/get_club_feed
 *
 * Gets feed for book club
 */
router.route('/groups/get_club_feed').post(async (req, res, next) => {
  try {
    if (!req.body.clubId) {
      throw new Error('Request is missing club id');
    }
    const db = dbConn.db('pageturner');
    let feed = await db.collection('comments')
        .find({scope: req.body.clubId}) // Note: keep as a string
        .sort({'metadata.timestamp': -1})
        .skip(20*req.body.pageNumber)
        .limit(20)
        .toArray();

    // Add profile and parent info to comments
    feed = await addProfiles(feed);
    feed = await addParents(feed);

    await res.send({feed});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /groups/get_profile/:uid
 *
 * Gets a group profile given the id
 */
router.route('/groups/get_profile').post(async (req, res, next) => {
  try {
    if (!req.body.id) {
      throw new Error('Request is missing uid');
    }
    req.body.id = new ObjectId(req.body.id);
    const db = dbConn.db('pageturner');
    const result = await db.collection('groups').find({_id: req.body.id}).toArray();
    await res.send({result});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /groups/create
 *
 * Create a group
 * Requires user is logged in
 */
router.route('/groups/create').post(async (req, res, next) => {
  try {
  // Require user is logged in
    if (!req.user) {
      throw new Error('Unauthenticated request');
    }

    // Require tag was provided
    if (!req.body.newGroupProfile.tag) {
      throw new Error('Request is missing group tag');
    }

    const db = dbConn.db('pageturner');
    const query = {tag: String(req.body.newGroupProfile.tag)}; // Identify group with this tag
    // Update with all editable fields sent with the new profile
    const update = {'$setOnInsert': req.body.newGroupProfile}; // Insert group with all fields found in req.body.newGroupProfile
    const options = {upsert: true}; // Update or insert if no such group exists
    const result = await db.collection('groups').findOne(query); // checks if the tag already exists

    await db.collection('groups').updateOne(query, update, options); // inserts new group if tag doesn't already exist

    await res.send({result}); // returns null if already exists, else returns newly created group
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /groups/update_profile
 *
 * Updates user profile after edits
 */
router.route('/groups/update_profile').post(async (req, res, next) => {
  try {
    if (!req.user) {
      throw new Error('User is not logged in');
    }
    const id = new ObjectId(req.body.newProfile._id);
    const editableFields = ['name', 'tag', 'description', 'banner_picture'];
    for (const field in req.body.newProfile) {
      if (!editableFields.includes(field)) {
        delete req.body.newProfile[field];
      }
    }

    const db = dbConn.db('pageturner');
    const query = {_id: new ObjectId(id)}; // Identify group with this tag

    // Update with all editable fields sent with the new profile
    const update = {'$set': req.body.newProfile}; // Update all fields found in req.body.newProfile
    const options = {upsert: true}; // Update or insert if no such group exists
    await db.collection('groups').updateOne(query, update, options);

    // Send the updated record back (in case update failed)
    const result = await db.collection('groups').findOne(query);
    await res.send({result});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /groups/join
 *
 * Join a public group / request to join a private group
 *
 * @param req.body.groupId - ID of group
 */
router.route('/groups/join').post(async (req, res, next) => {
  try {
    // Require user is logged in
    if (!req.user) {
      throw new Error('Unauthenticated request');
    }

    // Require group ID was provided
    if (!req.body.groupId) {
      throw new Error('Request is missing group ID');
    }

    // Ensure the group exists
    const db = dbConn.db('pageturner');
    const group = await db.collection('groups').findOne({_id: req.user._id});
    if (!group) {
      throw new Error('No such group exists');
    }

    // Update the group
    const update = group.private ? {'$addToSet': {pendingMembers: req.user._id}} : {'$addToSet': {members: req.user._id}};
    await db.collection('groups').updateOne({_id: req.body.shelfId}, update);
    await res.send({success: true});
  } catch (error) {
    console.error(error);
    next();
  }
});

/**
 * POST: /groups/accept_member
 *
 * Accept a new member to a private group
 * Requires user is logged in, is an admin
 *
 * @param req.body.groupId - ID of group
 * @param req.body.newMemberId - ID of member to add
 */
router.route('/groups/accept_member').post(async (req, res, next) => {
  try {
    // Require user is logged in
    if (!req.user) {
      throw new Error('Unauthenticated request');
    }

    // Require group ID was provided
    if (!req.body.groupId) {
      throw new Error('Request is missing group ID');
    }

    // Require newMemberId was provided
    if (!req.body.newMemberId) {
      throw new Error('Request is missing newMemberId');
    }

    // The user must be an admin
    const db = dbConn.db('pageturner');
    const group = await db.collection('groups').findOne({_id: req.user._id});
    if (!group) {
      throw new Error('No such group exists');
    }
    if (!group.admins.includes(req.user._id)) {
      throw new Error('The user is unauthorized to change this group');
    }

    // newMemberId must appear on pendingMembers list
    if (!group.pendingMembers.includes(req.body.newMemberId)) {
      throw new Error('The provided newMemberId does not match any pending member');
    }

    // Update the group
    await db.collection('groups').updateOne({_id: req.body.shelfId}, {
      '$addToSet': {members: req.body.newMemberId},
      '$pull': {pendingMembers: req.body.newMemberId},
    });
    await res.send({success: true});
  } catch (error) {
    console.error(error);
    next();
  }
});

module.exports = router;
